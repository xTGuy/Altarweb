function love.conf(t)
    t.window.title = "Snake"
    t.window.icon = nil
end